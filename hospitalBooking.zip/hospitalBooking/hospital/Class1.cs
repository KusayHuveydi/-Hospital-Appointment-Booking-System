﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace hastane
{
    internal class Class1
    {
        static string dosya = @"dosya.txt";

        public static void Ekle(string satir)
        {
            StreamWriter dosyay = new StreamWriter(dosya,true);
            dosyay.WriteLine(satir);
            dosyay.Close();
        }

        public static string Listele()
        {
            string tum;
            StreamReader dosyao = new StreamReader(dosya);
            tum =dosyao.ReadToEnd();
            dosyao.Close();
            return tum;
        }

        public static bool listedeVarmi(string bolum, string tarih, string saat)
        {
            StreamReader Varm = new StreamReader(dosya);
            string satir = "";
            bool sonuc = false;

            while (!Varm.EndOfStream)
            {
                satir = Varm.ReadLine();
                string[] parca = satir.Split('*');
                if (bolum == parca[3] && saat == parca[4] && tarih == parca[5])
                {
                    Varm.Close();
                    return true;
                }
            }
            Varm.Close();
            return false;
        }

       public static string secileTcrandecvu(string kn)
        {
           StreamReader Varm = new StreamReader(dosya);
           string satır = "";
           string se = "";
           while (!Varm.EndOfStream)
            {
                satır = Varm.ReadLine();
                string[] s = satır.Split('*');
                if (kn == s[0])
                {
                    se += satır+Environment.NewLine;
                }
            }
            Varm.Close();
            return se;
        }
       
    }
}
