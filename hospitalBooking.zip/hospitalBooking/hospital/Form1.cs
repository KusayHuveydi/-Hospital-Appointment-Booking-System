﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hastane
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string tckimlik = textBox1.Text;
            string adı = textBox2.Text;
            string soyadı = textBox3.Text;
            string klinik = comboBox1.SelectedItem.ToString();
            string saat = comboBox2.SelectedItem.ToString();
            string tarih = dateTimePicker1.Value.ToShortDateString();
            string satır = tckimlik + "*" + adı + "*" + soyadı + "*" + klinik + "*" + saat + "*" + tarih;
           

            try
            {
                if (Class1.listedeVarmi(klinik, tarih, saat))
                {
                    MessageBox.Show("sectiginz saat ve tarih dolu");
                }
                else
                {
                    Class1.Ekle(satır); MessageBox.Show("eklendi");
                }
            }
            catch
            {
                MessageBox.Show("Eklenmedi");
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
           textBox4.Text= Class1.Listele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string tc = textBox1.Text;
            if (Class1.secileTcrandecvu(tc) != "")
                textBox4.Text = Class1.secileTcrandecvu(tc);
            else
                MessageBox.Show("secilen kn ait randevular bulunmadı");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
